from .Detector import Detector

detector = Detector()
__all__ = ["detector", "Detector"]
